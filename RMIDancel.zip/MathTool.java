package rmi2;

import java.rmi.*;
import java.rmi.server.UnicastRemoteObject;

public class MathTool extends UnicastRemoteObject implements MathClassInterface {

    private String message;

    public MathTool() throws RemoteException {

    }

    public int add(int n1, int n2) throws RemoteException {
        return n1 + n2;
    }

    public int subtract(int n1, int n2) throws RemoteException {
        return n1 - n2;
    }

    public int multiply(int n1, int n2) throws RemoteException {
        return n1 * n2;
    }

    public int divide(int n1, int n2) throws RemoteException {

        return n1 / n2;

    }
}
