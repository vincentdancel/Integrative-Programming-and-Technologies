package rmi2;

import java.rmi.Naming;
import java.rmi.Remote;
import java.rmi.registry.Registry;
import java.rmi.registry.LocateRegistry;

public class RMIServer {

    public static void main(String[] args) {
        try {

            Registry r = java.rmi.registry.LocateRegistry.createRegistry(1099);
            r.rebind("server1", (Remote) new MathTool());
            System.out.println("Server is connected and ready for operation.");
        } catch (Exception e) {
            System.out.println("Server not connected: " + e);
        }

    }
}
