
package mockdata;

import java.awt.event.ActionEvent;
import java.io.*;
import java.net.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;


public class Client extends javax.swing.JFrame {
    

    public Client() {
        initComponents();
        addActionListeners();
        setResizable(false);
        loadCSVData();
        
    }

    private void addActionListeners() {
        RecordBtn.addActionListener((ActionEvent evt) -> viewSelectedRecord());  // Show details of selected row
        XMLBtn.addActionListener((ActionEvent evt) -> showXMLData());  // Show selected record as XML
        DownloadBtn.addActionListener((ActionEvent evt) -> downloadData());  // Download all data as XML file
    }

    /**
     * Connects to server and loads CSV data into the JTable.
     */
    private void loadCSVData() {
        try (
            Socket socket = new Socket("localhost", 5000);
            PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()))
        ) {
            
            out.println("CSV");  // Request CSV data from server
            DefaultTableModel model = (DefaultTableModel) DataTbl.getModel();
            model.setRowCount(0);  // Clear existing rows before loading new data

            String line;
            // Read each line from server and add to table
            while ((line = in.readLine()) != null) {
                String[] row = line.split(",", -1);  // Split CSV line into columns, preserve empty fields

                if (row.length == 6) {  // Validate expected column count
                    model.addRow(new Object[]{
                        row[0],  // firstName
                        row[1],  // lastName
                        row[2],  // gender
                        row[3],  // ip address
                        row[4],  // description
                        row[5]   // location
                    });
                } else {
                    System.err.println("Skipping line due to incorrect columns count: " + line);
                }
            }

        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage(), "Connection Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Displays details of the currently selected row in the JTable.
     */
    private void viewSelectedRecord() {
        int selectedRow = DataTbl.getSelectedRow();
        if (selectedRow == -1) {  // No row selected
            JOptionPane.showMessageDialog(this, "Please select a row first.", "No Selection", JOptionPane.WARNING_MESSAGE);
            return;
        }

        DefaultTableModel model = (DefaultTableModel) DataTbl.getModel();

        // Retrieve column values from selected row
        String firstname = model.getValueAt(selectedRow, 0).toString();
        String lastname = model.getValueAt(selectedRow, 1).toString();
        String gender = model.getValueAt(selectedRow, 2).toString();
        String ipAddress = model.getValueAt(selectedRow, 3).toString();
        String description = model.getValueAt(selectedRow, 4).toString();
        String location = model.getValueAt(selectedRow, 5).toString();

        // Prepare message to show
        String message = "First Name: " + firstname + "\n"
                + "Last Name: " + lastname + "\n"
                + "Gender: " + gender + "\n"
                + "IP Address: " + ipAddress + "\n"
                + "Description: " + description + "\n"
                + "Location: " + location;

        // Show details in a popup dialog
        JOptionPane.showMessageDialog(this, message, "Selected Record Details", JOptionPane.INFORMATION_MESSAGE);
    }

    /**
     * Shows XML representation of the selected record in a dialog.
     */
    private void showXMLData() {
        int selectedRow = DataTbl.getSelectedRow();
        if (selectedRow == -1) {  // No row selected
            JOptionPane.showMessageDialog(this, "Please select a row first.", "No Selection", JOptionPane.WARNING_MESSAGE);
            return;
        }

        DefaultTableModel model = (DefaultTableModel) DataTbl.getModel();

        // Retrieve column values from selected row
        String firstName = model.getValueAt(selectedRow, 0).toString();
        String lastName = model.getValueAt(selectedRow, 1).toString();
        String gender = model.getValueAt(selectedRow, 2).toString();
        String ipAdd = model.getValueAt(selectedRow, 3).toString();
        String description = model.getValueAt(selectedRow, 4).toString();
        String location = model.getValueAt(selectedRow, 5).toString();

        // Build XML string for selected record
        StringBuilder xmlBuilder = new StringBuilder();
        xmlBuilder.append("<clients>\n");
        xmlBuilder.append("  <client>\n");
        xmlBuilder.append("    <firstName>").append(firstName).append("</firstName>\n");
        xmlBuilder.append("    <lastName>").append(lastName).append("</lastName>\n");
        xmlBuilder.append("    <gender>").append(gender).append("</gender>\n");
        xmlBuilder.append("    <ip_add>").append(ipAdd).append("</ip_add>\n");
        xmlBuilder.append("    <description>").append(description).append("</description>\n");
        xmlBuilder.append("    <location>").append(location).append("</location>\n");
        xmlBuilder.append("  </client>\n");
        xmlBuilder.append("</clients>");

        // Display XML in a scrollable text area inside a dialog
        JTextArea textArea = new JTextArea(xmlBuilder.toString());
        textArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setPreferredSize(new java.awt.Dimension(400, 200));

        JOptionPane.showMessageDialog(this, scrollPane, "XML Data for Selected Record", JOptionPane.INFORMATION_MESSAGE);
    }

    /**
     * Downloads the entire XML data from the server and saves it to a user-chosen file.
     */
    private void downloadData() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Save XML");
        
        // Suggest default filename
        fileChooser.setSelectedFile(new File("Client.xml"));
        
        int userSelection = fileChooser.showSaveDialog(this);
        if (userSelection == JFileChooser.APPROVE_OPTION) {
            File fileToSave = fileChooser.getSelectedFile();

            try (
                Socket socket = new Socket("localhost", 5000);
                PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
                BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                FileWriter fw = new FileWriter(fileToSave)
            ) {

                out.println("XML");  // Request full XML data from server

                String line;
                // Write each line received from server into the selected file
                while ((line = in.readLine()) != null) {
                    fw.write(line + "\n");
                }

                // Notify user of success
                JOptionPane.showMessageDialog(this, "File saved successfully.");

            } catch (IOException e) {
                JOptionPane.showMessageDialog(this, "Error: " + e.getMessage(), "Save Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }


    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        DataTbl = new javax.swing.JTable();
        RecordBtn = new javax.swing.JButton();
        XMLBtn = new javax.swing.JButton();
        DownloadBtn = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        DataTbl.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "FIRSTNAME", "LASTNAME", "Gender", "IPAddress", "Description", "Location"
            }
        ));
        jScrollPane1.setViewportView(DataTbl);

        RecordBtn.setText("View Record");

        XMLBtn.setText("View XML");

        DownloadBtn.setText("Download");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 728, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(RecordBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(XMLBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(DownloadBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(RecordBtn)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(XMLBtn)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(DownloadBtn))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 275, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Client.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Client.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Client.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Client.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Client().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable DataTbl;
    private javax.swing.JButton DownloadBtn;
    private javax.swing.JButton RecordBtn;
    private javax.swing.JButton XMLBtn;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
