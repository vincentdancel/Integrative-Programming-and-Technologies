package mockdata;

import java.io.*;
import java.net.*;
import java.util.*;

public class Server {

    private static final int PORT = 5000;  // Server port to listen on
    private static final String CSV_FILE = "./src/MockData/MOCK_DATA.csv";  // Path to CSV file

    public static void main(String[] args) {
        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            System.out.println("Server is running on port " + PORT);

            while (true) {
                // Wait for client connection
                try (Socket clientSocket = serverSocket.accept()) {
                    System.out.println("Client connected.");

                    // Setup input stream to read commands from client
                    BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                    // Setup output stream to send responses to client
                    PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);

                    String command = in.readLine();  // Read command from client ("CSV" or "XML")
                    System.out.println("Received command: " + command);

                    // Read all records from CSV file
                    List<String[]> records = readCSV(CSV_FILE);

                    // Respond based on client command
                    if (command.equalsIgnoreCase("CSV")) {
                        // Send all CSV records line by line as comma-separated strings
                        for (String[] row : records) {
                            out.println(String.join(",", row));
                        }
                    } else if (command.equalsIgnoreCase("XML")) {
                        // Send all records formatted as XML
                        out.println("<clients>");
                        for (String[] row : records) {
                            out.println("  <client>");
                            out.println("    <firstName>" + row[0] + "</firstName>");
                            out.println("    <lastName>" + row[1] + "</lastName>");
                            out.println("    <gender>" + row[2] + "</gender>");
                            out.println("    <ip_add>" + row[3] + "</ip_add>");
                            out.println("    <description>" + row[4] + "</description>");
                            out.println("    <location>" + row[5] + "</location>");
                            out.println("  </client>");
                        }
                        out.println("</clients>");
                    } else {
                        // If command is not recognized, send error message
                        out.println("Invalid command.");
                    }

                } catch (IOException e) {
                    System.err.println("Client connection error: " + e.getMessage());
                }
            }

        } catch (IOException e) {
            System.err.println("Server error: " + e.getMessage());
        }
    }

    /**
     * Reads the CSV file and returns a list of records,
     * where each record is represented as a String array.
     * 
     * @param filePath The path to the CSV file
     * @return List of String arrays representing CSV rows
     */
    private static List<String[]> readCSV(String filePath) {
        List<String[]> records = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;

            // Read CSV line by line
            while ((line = br.readLine()) != null) {
                // Split the line by commas, preserving empty fields
                String[] data = line.split(",", -1);

                // Only add lines with exactly 6 columns (validate data format)
                if (data.length == 6) {
                    records.add(data);
                } else {
                    // Log if a line has an unexpected number of columns
                    System.err.println("Skipping line due to incorrect columns count: " + line);
                }
            }
        } catch (IOException e) {
            System.err.println("Failed to read CSV: " + e.getMessage());
        }

        System.out.println("Total records read: " + records.size());  // Log number of records loaded
        return records;
    }
}
